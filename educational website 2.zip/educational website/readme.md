Group names
1. michael tweolde 
2. michael ketema
3. helina taye
4. alazar nigusse
5. Abraham zegeye
6. Melat abebe
